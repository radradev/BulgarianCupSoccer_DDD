﻿using Microsoft.EntityFrameworkCore;
using BulgarianCup.Domain.Entities;

namespace BulgarianCup.Infra.InMemory.Context
{

    public class BulgarianCupContext : DbContext
    {
        public DbSet<Team> Teams { get; set; }

        public BulgarianCupContext(DbContextOptions<BulgarianCupContext> options)
        : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase("BulgarianCupDB");
        }
    }
}
