﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using BulgarianCup.Domain.Interfaces.Repositories;
using BulgarianCup.Infra.InMemory.Context;

namespace BulgarianCup.Infra.InMemory.Repositories
{

    public class BaseRepository<TEntity> : IDisposable, 
        IBaseRepository<TEntity> where TEntity : class
    {
        private readonly BulgarianCupContext _ctx;

        public BaseRepository(BulgarianCupContext context)
        {
            _ctx = context;
        }
        public TEntity Add(TEntity obj)
        {
            _ctx.Set<TEntity>().Add(obj);
            _ctx.SaveChanges();
            return obj;            
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        public IEnumerable<TEntity> GetAll()
        {
            return _ctx.Set<TEntity>().ToList();            
        }

        public TEntity GetById(long id)
        {
            return _ctx.Set<TEntity>().Find(id);            
        }

        public bool Remove(long id)
        {
            var obj = _ctx.Set<TEntity>().Find(id);
            _ctx.Set<TEntity>().Remove(obj);
            _ctx.SaveChanges();
            return true;
        }

        public bool Update(TEntity obj)
        {
            _ctx.Entry<TEntity>(obj).State = EntityState.Modified;
            _ctx.SaveChanges();
            return true;            
        }
    }
}
