﻿using BulgarianCup.Domain.Entities;
using BulgarianCup.Domain.Interfaces;
using BulgarianCup.Domain.Interfaces.Repositories;
using BulgarianCup.Infra.InMemory.Context;

namespace BulgarianCup.Infra.InMemory.Repositories
{
    public class TeamRepository : BaseRepository<Team>, ITeamRepository
    {
        public TeamRepository(BulgarianCupContext context) : base(context)
        {
        }
    }
}
