﻿using System;
using System.Collections.Generic;
using System.Text;
using BulgarianCup.Domain.Entities;

namespace BulgarianCup.DomainService.Interfaces
{
    public interface ITeamService : IBaseService<Team>
    {
    }
}
