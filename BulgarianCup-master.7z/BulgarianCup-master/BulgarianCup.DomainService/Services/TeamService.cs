﻿using BulgarianCup.Domain.Entities;
using BulgarianCup.Domain.Interfaces.Repositories;
using BulgarianCup.DomainService.Interfaces;

namespace BulgarianCup.DomainService.Services
{
    public class TeamService : BaseService<Team>, ITeamService
    {
        public TeamService(IBaseRepository<Team> baseRepository) : base(baseRepository)
        {
        }
    }
}
