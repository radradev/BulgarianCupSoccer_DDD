﻿namespace BulgarianCup.Domain.Entities
{
    public class Flag : File
    {
        
    }
}
