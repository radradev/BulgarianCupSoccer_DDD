﻿using BulgarianCup.Domain.Entities;

namespace BulgarianCup.Domain.Interfaces.Repositories
{
    public interface ITeamRepository : IBaseRepository<Team>
    {
    }
}
