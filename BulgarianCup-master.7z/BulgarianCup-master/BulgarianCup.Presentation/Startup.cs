﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using BulgarianCup.Application;
using BulgarianCup.Application.Interfaces;
using BulgarianCup.Domain.Entities;
using BulgarianCup.Domain.Interfaces.Repositories;
using BulgarianCup.DomainService.Interfaces;
using BulgarianCup.DomainService.Services;
using BulgarianCup.Infra.InMemory.Context;
using BulgarianCup.Infra.InMemory.Repositories;

namespace BulgarianCup.Presentation
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<BulgarianCupContext>(opt => opt.UseInMemoryDatabase(databaseName: "BulgarianCupDB"));
            services.AddTransient<IBaseAppService<Team>, BaseAppService<Team>>();
            services.AddTransient<ITeamAppService, TeamAppService>();
            services.AddTransient<IRafflesAppService, RafflesAppService>();
            services.AddTransient<IMatchAppService, MatchAppService>();

            services.AddTransient<IBaseService<Team>, BaseService<Team>>();
            services.AddTransient<ITeamService, TeamService>();
            services.AddTransient<IRafflesService, RafflesService>();
            services.AddTransient<IMatchService, MatchService>();

            services.AddTransient<IBaseRepository<Team>, BaseRepository<Team>>();
            services.AddTransient<ITeamRepository, TeamRepository>();            

            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Team}/{action=Index}/{id?}");
            });
        }
    }
}
