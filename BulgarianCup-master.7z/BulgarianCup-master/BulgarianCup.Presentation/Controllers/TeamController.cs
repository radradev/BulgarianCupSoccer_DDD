﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using BulgarianCup.Application.Interfaces;
using BulgarianCup.Domain.Entities;

namespace BulgarianCup.Presentation.Controllers
{
    public class TeamController : Controller
    {
        private readonly ITeamAppService _teamAppService;
        private readonly IMatchAppService _matchAppService;
        private readonly IRafflesAppService _rafflesAppService;

        public TeamController(ITeamAppService teamAppService,
            IMatchAppService matchAppService, IRafflesAppService rafflesAppService)
        {
            _teamAppService = teamAppService;
            _matchAppService = matchAppService;
            _rafflesAppService = rafflesAppService;
        }


        // GET: Team
        public ActionResult Index()
        {
            //################################################# OCTAVES FINAL ############################################

            _teamAppService.Add(new Team("CSKA-SF", "CSF"));
            _teamAppService.Add(new Team("LEVSKI", "LEV"));
            _teamAppService.Add(new Team("SLAVIA", "SLA"));
            _teamAppService.Add(new Team("LOKO-PL", "LPL"));
            _teamAppService.Add(new Team("LOKO-SF", "LSF"));
            _teamAppService.Add(new Team("BOTEV-PL", "BPL"));
            _teamAppService.Add(new Team("BOTEV-VR", "BVR"));
            _teamAppService.Add(new Team("LITEX", "LIT"));
            _teamAppService.Add(new Team("MONTANA", "MON"));
            _teamAppService.Add(new Team("BEROE", "BER"));
            _teamAppService.Add(new Team("ETER", "ETE"));
            _teamAppService.Add(new Team("VITOSHA", "VIT"));
            _teamAppService.Add(new Team("ARDA", "ARD"));
            _teamAppService.Add(new Team("MEZDRA", "MEZ"));
            _teamAppService.Add(new Team("DUNAV", "DUN"));
            _teamAppService.Add(new Team("CSKA1948", "C48"));


            var selections = _teamAppService.GetAll().ToList();                        
            var selectionsRafflesOctavesFinals = _rafflesAppService.RafflesOctavesFinal(selections);
            

            var resultOctavesFinal = _matchAppService.PlayOctavesFinal(selectionsRafflesOctavesFinals);


            ViewBag.resultOctavesFinal = resultOctavesFinal;
            var winnersOctaves = resultOctavesFinal.Values.ElementAt(0);
            var disqualifiedsOctaves = resultOctavesFinal.Values.ElementAt(1);

            //################################################# QUATER FINALS ##############################################

            ViewBag.classifiedSelectionsForQuarterFinals = resultOctavesFinal;


            var selectionsRafflesQuarterFinals = _rafflesAppService.RafflesQuarterFinal(winnersOctaves);
            ViewBag.selectionsRafflesQuarterFinals = selectionsRafflesQuarterFinals;


            var classifiedSelectionsForSemiFinal = _matchAppService.PlayQuarterFinal(selectionsRafflesQuarterFinals);


            var winnersQuarters = classifiedSelectionsForSemiFinal.Values.ElementAt(0);
            var disqualifiedsQuarters = classifiedSelectionsForSemiFinal.Values.ElementAt(1);

            //#################################################### SEMI-FINALS #################################################
                        
            ViewBag.classifiedSelectionsForSemiFinals = classifiedSelectionsForSemiFinal;
            var selectionsRafflesSemiFinals = _rafflesAppService.RafflesSemiFinal(winnersQuarters);
            ViewBag.selectionsRafflesSemiFinals = selectionsRafflesSemiFinals;


            var classifiedSelectionsForFinal = _matchAppService.PlaySemiFinal(selectionsRafflesSemiFinals);


            var winnersSemiFinal = classifiedSelectionsForFinal.Values.ElementAt(0);
            var disqualifiedsSemiFinal = classifiedSelectionsForFinal.Values.ElementAt(1);

            //###################################################### FINALS ####################################################

            ViewBag.classifiedSelectionsForFinal = classifiedSelectionsForFinal;
            var selectionChampion = _matchAppService.PlayFinal(winnersSemiFinal);

            return View();
        }

        // GET: Team/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Team/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Team/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
               

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Team/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Team/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Team/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Team/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}