﻿using BulgarianCup.Application.Interfaces;
using BulgarianCup.Domain.Entities;
using BulgarianCup.DomainService.Interfaces;

namespace BulgarianCup.Application
{
    public class TeamAppService : BaseAppService<Team>, ITeamAppService
    {
        public TeamAppService(IBaseService<Team> baseService) : base(baseService)
        {
        }
    }
}
