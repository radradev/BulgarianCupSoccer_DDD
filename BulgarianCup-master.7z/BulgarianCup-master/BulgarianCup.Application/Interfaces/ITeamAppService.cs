﻿using BulgarianCup.Domain.Entities;

namespace BulgarianCup.Application.Interfaces
{
    public interface ITeamAppService : IBaseAppService<Team>
    {
    }
}
