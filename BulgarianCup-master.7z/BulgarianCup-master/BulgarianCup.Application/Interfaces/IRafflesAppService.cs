﻿using System.Collections.Generic;
using BulgarianCup.Domain.Entities;

namespace BulgarianCup.Application.Interfaces
{
    public interface IRafflesAppService
    {
        Dictionary<string, List<Team>> RafflesOctavesFinal(List<Team> selections);
        Dictionary<string, List<Team>> RafflesQuarterFinal(List<Team> selections);
        Dictionary<string, List<Team>> RafflesSemiFinal(List<Team> selections);
    }
}
