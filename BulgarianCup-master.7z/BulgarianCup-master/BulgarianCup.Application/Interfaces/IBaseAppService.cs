﻿using System.Collections.Generic;

namespace BulgarianCup.Application.Interfaces
{
    public interface IBaseAppService<TEntity> where TEntity : class
    {
        IEnumerable<TEntity> GetAll();
        TEntity GetById(long id);
        TEntity Add(TEntity obj);
        bool Remove(long id);
        bool Update(TEntity obj);
        void Dispose();
    }
}
