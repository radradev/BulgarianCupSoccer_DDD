﻿using Microsoft.EntityFrameworkCore;
using System;
using BulgarianCup.DomainService.Interfaces;
using BulgarianCup.DomainService.Services;
using BulgarianCup.Infra.InMemory.Context;
using BulgarianCup.Infra.InMemory.Repositories;
using Xunit;
using BulgarianCup.Domain.Interfaces.Repositories;
using System.Linq;
using BulgarianCup.Domain.Entities;
using System.Collections.Generic;

namespace BulgarianCup.XUnitTest
{
    public class MatchServiceTest : IDisposable
    {
        private readonly IMatchService _matchService;
        private readonly IRafflesService _rafflesService;
        private readonly ITeamRepository _teamRepository;
        private List<Team> finals;

        public MatchServiceTest()
        {
            _matchService = new MatchService(GetInMemoryTeamRepository());
            _rafflesService = new RafflesService(GetInMemoryTeamRepository());
            _teamRepository = GetInMemoryTeamRepository();
            finals = new List<Team>();
        }

        [Fact]
        public void TestListTeamsOctavesFinal()
        {
            /* ================== Teams =================== */            

            _teamRepository.Add(new Team("CSKA-SF", "CSF"));
            _teamRepository.Add(new Team("LEVSKI", "LEV"));
            _teamRepository.Add(new Team("SLAVIA", "SLA"));
            _teamRepository.Add(new Team("LOKO-PL", "LPL"));
            _teamRepository.Add(new Team("LOKO-SF", "LSF"));
            _teamRepository.Add(new Team("BOTEV-PL", "BPL"));
            _teamRepository.Add(new Team("BOTEV-VR", "BVR"));
            _teamRepository.Add(new Team("LITEX", "LIT"));
            _teamRepository.Add(new Team("MONTANA", "MON"));
            _teamRepository.Add(new Team("BEROE", "BER"));
            _teamRepository.Add(new Team("ETER", "ETE"));
            _teamRepository.Add(new Team("VITOSHA", "VIT"));
            _teamRepository.Add(new Team("ARDA", "ARD"));
            _teamRepository.Add(new Team("MEZDRA", "MEZ"));
            _teamRepository.Add(new Team("DUNAV", "DUN"));
            _teamRepository.Add(new Team("CSKA1948", "C48"));

            var selections = _teamRepository.GetAll().ToList();


            var list = _matchService.PlayOctavesFinal(_rafflesService.RafflesOctavesFinal(selections));



            Assert.NotEmpty(list);
            Assert.Equal(2, list.Count);
         
        }

        [Fact]
        public void TestListTeamsQuarterFinal()
        {


            _teamRepository.Add(new Team("CSKA-SF", "CSF"));
            _teamRepository.Add(new Team("LEVSKI", "LEV"));
            _teamRepository.Add(new Team("SLAVIA", "SLA"));
            _teamRepository.Add(new Team("LOKO-PL", "LPL"));
            _teamRepository.Add(new Team("LOKO-SF", "LSF"));
            _teamRepository.Add(new Team("BOTEV-PL", "BPL"));
            _teamRepository.Add(new Team("BOTEV-VR", "BVR"));
            _teamRepository.Add(new Team("LITEX", "LIT"));

            var selections = _teamRepository.GetAll().ToList();


            var list = _matchService.PlayQuarterFinal(_rafflesService.RafflesQuarterFinal(selections));



            Assert.NotEmpty(list);
            Assert.Equal(2, list.Count);



        }

        [Fact]
        public void TestListTeamsSemiFinal()
        {


            _teamRepository.Add(new Team("CSKA-SF", "CSF"));
            _teamRepository.Add(new Team("LEVSKI", "LEV"));
            _teamRepository.Add(new Team("SLAVIA", "SLA"));
            _teamRepository.Add(new Team("LOKO-PL", "LPL"));

            var selections = _teamRepository.GetAll().ToList();

            var finals = _matchService.PlaySemiFinal(_rafflesService.RafflesSemiFinal(selections));




            Assert.NotEmpty(finals);
            Assert.Equal(2, finals.Count);



        }

        [Fact]
        public void TestPlayFinal()
        {


            _teamRepository.Add(new Team("CSKA-SF", "CSF"));
            _teamRepository.Add(new Team("LEVSKI", "LEV"));

            var selections = _teamRepository.GetAll().ToList();


            var championTeam = _matchService.PlayFinal(selections);




            Assert.NotNull(championTeam.Name);


        }

        private ITeamRepository GetInMemoryTeamRepository()
        {
            DbContextOptions<BulgarianCupContext> options;
            var builder = new DbContextOptionsBuilder<BulgarianCupContext>();
            options = builder.UseInMemoryDatabase(databaseName: "BulgarianCupDB").Options;
            var BulgarianCupContext = new BulgarianCupContext(options);
            BulgarianCupContext.Database.EnsureDeleted();
            BulgarianCupContext.Database.EnsureCreated();
            return new TeamRepository(BulgarianCupContext);
        }
        public void Dispose()
        {
            GC.SuppressFinalize(GetInMemoryTeamRepository());
        }
    }
}
