﻿using Microsoft.EntityFrameworkCore;
using BulgarianCup.Infra.InMemory.Context;
using BulgarianCup.Infra.InMemory.Repositories;
using Xunit;
using BulgarianCup.Domain.Entities;
using System.Linq;
using BulgarianCup.Domain.Interfaces.Repositories;
using System;

namespace BulgarianCup.XUnitTest
{

    public class TeamRepositoryTest : IDisposable
    {
        [Fact]
        public void TestAddTeam()
        {
            ITeamRepository teamRepository = GetInMemoryTeamRepository();
            var cskasf = new Team("CSKA-SF", "CSF");

            var teamSaved = teamRepository.Add(cskasf);

            Assert.NotEmpty(teamRepository.GetAll().ToList());
            Assert.Equal("CSKA-SF", teamSaved.Name);
            Assert.Equal("CSF", teamSaved.Flag);         
            
        }        

        private ITeamRepository GetInMemoryTeamRepository()
        {
            DbContextOptions<BulgarianCupContext> options;
            var builder = new DbContextOptionsBuilder<BulgarianCupContext>();
            options = builder.UseInMemoryDatabase(databaseName: "BulgarianCupDB").Options;
            var BulgarianCupContext = new BulgarianCupContext(options);
            BulgarianCupContext.Database.EnsureDeleted();
            BulgarianCupContext.Database.EnsureCreated();
            return new TeamRepository(BulgarianCupContext);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(GetInMemoryTeamRepository());
        }

    }
}
