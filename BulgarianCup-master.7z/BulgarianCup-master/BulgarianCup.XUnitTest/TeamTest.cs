using Xunit;
using FluentAssertions;
using BulgarianCup.Domain.Entities;
using System;

namespace BulgarianCup.XUnitTest
{

    public class TeamTest : IDisposable
    {
        private Team cskasf;

        [Fact]
        public void TestCreatingNewTeam()
        {

            cskasf = new Team { TeamId = 1, Name = "CSKA-SF", Flag = "CSF" };


            var teamName = cskasf.Name;
            var expectedTeamName = "CSKA-SF";


            teamName.Should().Be(expectedTeamName, 
                $"The name of the expected team does not match the object obtained ({teamName})");
        }

        public void Dispose()
        {
            GC.SuppressFinalize(cskasf);
        }
    }
}
