﻿using Xunit;
using BulgarianCup.DomainService.Interfaces;
using BulgarianCup.DomainService.Services;
using BulgarianCup.Infra.InMemory.Repositories;
using Microsoft.EntityFrameworkCore;
using BulgarianCup.Infra.InMemory.Context;
using System;
using BulgarianCup.Domain.Interfaces.Repositories;
using BulgarianCup.Domain.Entities;
using System.Linq;

namespace BulgarianCup.XUnitTest
{
    public class RafflesServiceTest : IDisposable
    {
        private readonly IRafflesService _rafflesService;
        private readonly ITeamRepository _teamRepository;

        public RafflesServiceTest()
        {
            _rafflesService = new RafflesService(GetInMemoryTeamRepository());
            _teamRepository = GetInMemoryTeamRepository();
        }

        [Fact]
        public void TestRafflesOctavesFinal()
        {


            _teamRepository.Add(new Team("CSKA-SF", "CSF"));
            _teamRepository.Add(new Team("LEVSKI", "LEV"));
            _teamRepository.Add(new Team("SLAVIA", "SLA"));
            _teamRepository.Add(new Team("LOKO-PL", "LPL"));
            _teamRepository.Add(new Team("LOKO-SF", "LSF"));
            _teamRepository.Add(new Team("BOTEV-PL", "BPL"));
            _teamRepository.Add(new Team("BOTEV-VR", "BVR"));
            _teamRepository.Add(new Team("LITEX", "LIT"));
            _teamRepository.Add(new Team("MONTANA", "MON"));
            _teamRepository.Add(new Team("BEROE", "BER"));
            _teamRepository.Add(new Team("ETER", "ETE"));
            _teamRepository.Add(new Team("VITOSHA", "VIT"));
            _teamRepository.Add(new Team("ARDA", "ARD"));
            _teamRepository.Add(new Team("MEZDRA", "MEZ"));
            _teamRepository.Add(new Team("DUNAV", "DUN"));
            _teamRepository.Add(new Team("CSKA1948", "C48"));

            var selections = _teamRepository.GetAll().ToList();


            var dict = _rafflesService.RafflesOctavesFinal(selections);


            Assert.True(dict.ContainsKey("Key:1"));
            Assert.Equal(8, dict.Count);

            
        }

        [Fact]
        public void TestRafflesQuarterFinal()
        {

            _teamRepository.Add(new Team("CSKA-SF", "CSF"));
            _teamRepository.Add(new Team("LEVSKI", "LEV"));
            _teamRepository.Add(new Team("SLAVIA", "SLA"));
            _teamRepository.Add(new Team("LOKO-PL", "LPL"));
            _teamRepository.Add(new Team("LOKO-SF", "LSF"));
            _teamRepository.Add(new Team("BOTEV-PL", "BPL"));
            _teamRepository.Add(new Team("BOTEV-VR", "BVR"));
            _teamRepository.Add(new Team("LITEX", "LIT"));

            var selections = _teamRepository.GetAll().ToList();

            var dict = _rafflesService.RafflesQuarterFinal(selections);

            Assert.True(dict.ContainsKey("Key:1"));
            Assert.Equal(4, dict.Count);

        }

        [Fact]
        public void TestRafflesSemiFinal()
        {

            _teamRepository.Add(new Team("CSKA-SF", "CSF"));
            _teamRepository.Add(new Team("LEVSKI", "LEV"));
            _teamRepository.Add(new Team("SLAVIA", "SLA"));
            _teamRepository.Add(new Team("LOKO-PL", "LPL"));

            var selections = _teamRepository.GetAll().ToList();

            var dict = _rafflesService.RafflesSemiFinal(selections);


            Assert.True(dict.ContainsKey("Key:1"));
            Assert.Equal(2, dict.Count);


        }

        private ITeamRepository GetInMemoryTeamRepository()
        {
            DbContextOptions<BulgarianCupContext> options;
            var builder = new DbContextOptionsBuilder<BulgarianCupContext>();
            options = builder.UseInMemoryDatabase(databaseName: "BulgarianCupDB").Options;
            var BulgarianCupContext = new BulgarianCupContext(options);
            BulgarianCupContext.Database.EnsureDeleted();
            BulgarianCupContext.Database.EnsureCreated();
            return new TeamRepository(BulgarianCupContext);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(GetInMemoryTeamRepository());
        }
    }
}
