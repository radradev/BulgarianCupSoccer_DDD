﻿using Xunit;
using Microsoft.EntityFrameworkCore;
using BulgarianCup.Infra.InMemory.Context;
using System.Linq;
using BulgarianCup.Domain.Entities;

namespace BulgarianCup.XUnitTest
{
    public class BulgarianCupContextTest 
    {        
        [Fact]
        public void TestBulgarianCupContext()
        {

            var options = new DbContextOptionsBuilder<BulgarianCupContext>()
                .UseInMemoryDatabase(databaseName: "BulgarianCupDB").Options;

            using (var ctx = new BulgarianCupContext(options))
            {
                ctx.Teams.Add(new Team { Name = "CSKA-SF", Flag = "CSF" });
                ctx.SaveChanges();



                Assert.NotEmpty(ctx.Teams.ToList());

            }
        }
        
    }
}
