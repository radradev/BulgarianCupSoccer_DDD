﻿using Microsoft.EntityFrameworkCore;
using BulgarianCup.Domain.Entities;
using BulgarianCup.DomainService.Interfaces;
using BulgarianCup.DomainService.Services;
using BulgarianCup.Infra.InMemory.Context;
using BulgarianCup.Infra.InMemory.Repositories;
using Xunit;
using System.Linq;
using System;

namespace BulgarianCup.XUnitTest
{

    public class TeamServiceTest : IDisposable
    {
        [Fact]
        public void TestAddTeam()
        {


            ITeamService teamService = new TeamService(GetInMemoryTeamRepository());
            var cskasf = new Team("CSKA-SF", "CSF");


            var teamSaved = teamService.Add(cskasf);


            Assert.NotEmpty(teamService.GetAll().ToList());

            Assert.Equal("CSKA-SF", teamSaved.Name);
            Assert.Equal("CSF", teamSaved.Flag);

        }

        private TeamRepository GetInMemoryTeamRepository()
        {
            DbContextOptions<BulgarianCupContext> options;
            var builder = new DbContextOptionsBuilder<BulgarianCupContext>();
            options = builder.UseInMemoryDatabase(databaseName: "BulgarianCupDB").Options;
            var BulgarianCupContext = new BulgarianCupContext(options);
            BulgarianCupContext.Database.EnsureDeleted();
            BulgarianCupContext.Database.EnsureCreated();
            return new TeamRepository(BulgarianCupContext);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(GetInMemoryTeamRepository());
        }
    }
}
