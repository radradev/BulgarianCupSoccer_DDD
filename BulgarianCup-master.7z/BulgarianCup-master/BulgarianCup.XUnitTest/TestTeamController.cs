﻿using Microsoft.EntityFrameworkCore;
using System;
using BulgarianCup.Application;
using BulgarianCup.Domain.Entities;
using BulgarianCup.Domain.Interfaces.Repositories;
using BulgarianCup.DomainService.Services;
using BulgarianCup.Infra.InMemory.Context;
using BulgarianCup.Infra.InMemory.Repositories;
using BulgarianCup.Presentation.Controllers;
using Xunit;
using FluentAssertions;

namespace BulgarianCup.XUnitTest
{
    public class TestTeamController : IDisposable
    {        
        [Fact]
        public void IndexTest()
        {


            var teamController = new TeamController(
                new TeamAppService(new BaseService<Team>(GetInMemoryTeamRepository())),
                new MatchAppService(new MatchService(GetInMemoryTeamRepository())),
                new RafflesAppService(new RafflesService(GetInMemoryTeamRepository())));


            var actionResult = teamController.Index();


            Assert.NotNull(actionResult);


            actionResult.Should().NotBeNull(actionResult.ToString(),
                $"The expected object does not correspond with the obtained object" +
                $" ({actionResult.ToString()})");

        }

        private ITeamRepository GetInMemoryTeamRepository()
        {
            DbContextOptions<BulgarianCupContext> options;
            var builder = new DbContextOptionsBuilder<BulgarianCupContext>();
            options = builder.UseInMemoryDatabase(databaseName: "BulgarianCupDB").Options;
            var BulgarianCupContext = new BulgarianCupContext(options);
            BulgarianCupContext.Database.EnsureDeleted();
            BulgarianCupContext.Database.EnsureCreated();
            return new TeamRepository(BulgarianCupContext);
        }
        public void Dispose()
        {
            GC.SuppressFinalize(GetInMemoryTeamRepository());
        }        
    }
}
