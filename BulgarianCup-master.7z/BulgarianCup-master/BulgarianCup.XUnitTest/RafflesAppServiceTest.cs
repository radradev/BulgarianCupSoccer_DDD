﻿using Microsoft.EntityFrameworkCore;
using System;
using BulgarianCup.Application;
using BulgarianCup.Application.Interfaces;
using BulgarianCup.Domain.Interfaces.Repositories;
using BulgarianCup.DomainService.Services;
using BulgarianCup.Infra.InMemory.Context;
using BulgarianCup.Infra.InMemory.Repositories;
using Xunit;
using BulgarianCup.Domain.Entities;
using System.Linq;

namespace BulgarianCup.XUnitTest
{
    public class RafflesAppServiceTest : IDisposable
    {
        private IRafflesAppService _rafflesAppService;
        private ITeamRepository _teamRepository;

        public RafflesAppServiceTest()
        {
            _rafflesAppService = new RafflesAppService(new RafflesService(GetInMemoryTeamRepository()));
            _teamRepository = GetInMemoryTeamRepository();
        }
        [Fact]
        public void TestRafflesAppServiceOctavesFinal()
        {


            _teamRepository.Add(new Team("CSKA-SF", "CSF"));
            _teamRepository.Add(new Team("LEVSKI", "LEV"));
            _teamRepository.Add(new Team("SLAVIA", "SLA"));
            _teamRepository.Add(new Team("LOKO-PL", "LPL"));
            _teamRepository.Add(new Team("LOKO-SF", "LSF"));
            _teamRepository.Add(new Team("BOTEV-PL", "BPL"));
            _teamRepository.Add(new Team("BOTEV-VR", "BVR"));
            _teamRepository.Add(new Team("LITEX", "LIT"));
            _teamRepository.Add(new Team("MONTANA", "MON"));
            _teamRepository.Add(new Team("BEROE", "BER"));
            _teamRepository.Add(new Team("ETER", "ETE"));
            _teamRepository.Add(new Team("VITOSHA", "VIT"));
            _teamRepository.Add(new Team("ARDA", "ARD"));
            _teamRepository.Add(new Team("MEZDRA", "MEZ"));
            _teamRepository.Add(new Team("DUNAV", "DUN"));
            _teamRepository.Add(new Team("CSKA1948", "C48"));

            var selections = _teamRepository.GetAll().ToList();



            var dict = _rafflesAppService.RafflesOctavesFinal(selections);



            Assert.True(dict.ContainsKey("Key:1"));
            Assert.Equal(8, dict.Count);



        }

        [Fact]
        public void TestRafflesAppServiceQuarterFinal()
        {


            _teamRepository.Add(new Team("CSKA-SF", "CSF"));
            _teamRepository.Add(new Team("LEVSKI", "LEV"));;
            _teamRepository.Add(new Team("SLAVIA", "SLA"));
            _teamRepository.Add(new Team("LOKO-PL", "LPL"));
            _teamRepository.Add(new Team("LOKO-SF", "LSF"));
            _teamRepository.Add(new Team("BOTEV-PL", "BPL"));
            _teamRepository.Add(new Team("BOTEV-VR", "BVR"));
            _teamRepository.Add(new Team("LITEX", "LIT"));

            var selections = _teamRepository.GetAll().ToList();


            var dict = _rafflesAppService.RafflesQuarterFinal(selections);




            Assert.True(dict.ContainsKey("Key:1"));
            Assert.Equal(4, dict.Count);



        }

        [Fact]
        public void TestRafflesAppServiceSemiFinal()
        {


            _teamRepository.Add(new Team("CSKA-SF", "CSF"));
            _teamRepository.Add(new Team("LEVSKI", "LEV"));;
            _teamRepository.Add(new Team("SLAVIA", "SLA"));
            _teamRepository.Add(new Team("LOKO-PL", "LPL"));

            var selections = _teamRepository.GetAll().ToList();

            var dict = _rafflesAppService.RafflesSemiFinal(selections);


            Assert.True(dict.ContainsKey("Key:1"));
            Assert.Equal(2, dict.Count);


        }

        private ITeamRepository GetInMemoryTeamRepository()
        {
            DbContextOptions<BulgarianCupContext> options;
            var builder = new DbContextOptionsBuilder<BulgarianCupContext>();
            options = builder.UseInMemoryDatabase(databaseName: "BulgarianCupDB").Options;
            var BulgarianCupContext = new BulgarianCupContext(options);
            BulgarianCupContext.Database.EnsureDeleted();
            BulgarianCupContext.Database.EnsureCreated();
            return new TeamRepository(BulgarianCupContext);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(GetInMemoryTeamRepository());
        }
    }
}
